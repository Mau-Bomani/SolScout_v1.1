
#pragma once
#include <string>
#include <vector>
#include <random>
#include <sstream>

namespace util {
    std::string generate_uuid();
    std::string current_iso8601();
    std::vector<std::string> split(const std::string& s, char delimiter);
    std::string trim(const std::string& str);
    std::string read_file(const std::string& path);
    bool is_valid_address(const std::string& address);
}
