
#pragma once
#include <string>
#include <stdexcept>
#include <cstdlib>
#include <fmt/core.h>

struct Config {
    // Service
    std::string service_name = "portfolio_service";
    std::string log_level = "info";

    // Redis
    std::string redis_host;
    int redis_port;
    std::string redis_password;
    std::string redis_cmd_channel;
    std::string redis_reply_channel;
    std::string redis_audit_channel;

    // PostgreSQL
    std::string db_conn_string;

    // External APIs
    std::string birdeye_api_key;
    std::string solana_rpc_url;

    // Health Check
    std::string health_check_host = "0.0.0.0";
    int health_check_port = 8081;

    static Config from_env();
    void validate() const;

private:
    static std::string get_env(const std::string& name, const std::string& default_val = "");
    static int get_env_int(const std::string& name, int default_val);
};
