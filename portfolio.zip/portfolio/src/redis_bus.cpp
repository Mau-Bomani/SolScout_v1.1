#include "redis_bus.hpp"
#include <spdlog/spdlog.h>

RedisBus::RedisBus(const Config& config) : config_(config) {
    sw::redis::ConnectionOptions conn_opts;
    conn_opts.host = config_.redis_host;
    conn_opts.port = config_.redis_port;
    if (!config_.redis_password.empty()) {
        conn_opts.password = config_.redis_password;
    }
    conn_opts.socket_timeout = std::chrono::milliseconds(500);

    redis_ = std::make_unique<sw::redis::Redis>(conn_opts);
    
    if (!redis_->ping().starts_with("PONG")) {
        throw std::runtime_error("Failed to connect to Redis");
    }
    spdlog::info("Successfully connected to Redis at {}:{}", config_.redis_host, config_.redis_port);
}

RedisBus::~RedisBus() {
    stop();
}

void RedisBus::subscribe_to_commands(MessageHandler handler) {
    if (running_) {
        spdlog::warn("Subscriber already running.");
        return;
    }
    message_handler_ = std::move(handler);
    running_ = true;
    subscriber_thread_ = std::thread(&RedisBus::subscriber_loop, this);
}

void RedisBus::publish_reply(const CommandReply& reply) {
    try {
        redis_->publish(config_.redis_reply_channel, reply.to_json().dump());
    } catch (const sw::redis::Error& e) {
        spdlog::error("Redis publish (reply) failed: {}", e.what());
    }
}

void RedisBus::publish_audit_event(const Audit& audit) {
    try {
        redis_->publish(config_.redis_audit_channel, audit.to_json().dump());
    } catch (const sw::redis::Error& e) {
        spdlog::error("Redis publish (audit) failed: {}", e.what());
    }
}

void RedisBus::stop() {
    if (running_.exchange(false)) {
        spdlog::info("Stopping Redis subscriber...");
        if (sub_) {
            // This will unblock the subscriber's consume() call
            sub_->unsubscribe();
        }
        if (subscriber_thread_.joinable()) {
            subscriber_thread_.join();
        }
        spdlog::info("Redis subscriber stopped.");
    }
}

void RedisBus::subscriber_loop() {
    sub_ = redis_->subscriber();
    sub_->on_message([this](std::string channel, std::string msg) {
        if (message_handler_) {
            message_handler_(msg);
        }
    });

    sub_->subscribe(config_.redis_cmd_channel);
    spdlog::info("Subscribed to Redis channel: {}", config_.redis_cmd_channel);

    while (running_) {
        try {
            sub_->consume();
        } catch (const sw::redis::TimeoutError &e) {
            // This is expected, just continue
            continue;
        } catch (const sw::redis::Error &e) {
            if (running_) { // Avoid logging error on clean shutdown
                spdlog::error("Redis subscription error: {}. Reconnecting in 5s...", e.what());
                std::this_thread::sleep_for(std::chrono::seconds(5));
            }
        }
    }
}