
#pragma once
#include "config.hpp"
#include "json_schemas.hpp"
#include <sw/redis++/redis++.h>
#include <functional>
#include <thread>
#include <atomic>
#include <memory>

class RedisBus {
public:
    using MessageHandler = std::function<void(const std::string&)>;

    RedisBus(const Config& config);
    ~RedisBus();

    void subscribe_to_commands(MessageHandler handler);
    void publish_reply(const CommandReply& reply);
    void publish_audit_event(const Audit& audit);
    void stop();

private:
    void subscriber_loop();

    Config config_;
    std::unique_ptr<sw::redis::Redis> redis_;
    std::unique_ptr<sw::redis::Subscriber> sub_;
    MessageHandler message_handler_;
    std::thread subscriber_thread_;
    std::atomic<bool> running_{false};
};
