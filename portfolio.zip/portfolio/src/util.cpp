#include "util.hpp"
#include <date/date.h>
#include <fstream>
#include <algorithm>
#include <cctype>

namespace util {

// ... existing code

std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t\n\r\f\v");
    if (std::string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(" \t\n\r\f\v");
    return str.substr(first, (last - first + 1));
}

std::string read_file(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        return "";
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

bool is_valid_address(const std::string& address) {
    // Basic Solana address validation: length and base58 characters
    if (address.length() < 32 || address.length() > 44) {
        return false;
    }
    const std::string b58_chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    return std::all_of(address.begin(), address.end(), [&](char c) {
        return b58_chars.find(c) != std::string::npos;
    });
}

} // namespace util