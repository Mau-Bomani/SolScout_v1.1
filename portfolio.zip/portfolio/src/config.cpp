
#include "config.hpp"

std::string Config::get_env(const std::string& name, const std::string& default_val) {
    const char* value = std::getenv(name.c_str());
    return value ? value : default_val;
}

int Config::get_env_int(const std::string& name, int default_val) {
    const char* value = std::getenv(name.c_str());
    if (!value) {
        return default_val;
    }
    try {
        return std::stoi(value);
    } catch (const std::exception& e) {
        throw std::runtime_error(fmt::format("Invalid integer value for env var {}: {}", name, value));
    }
}

Config Config::from_env() {
    Config cfg;
    cfg.log_level = get_env("LOG_LEVEL", "info");

    cfg.redis_host = get_env("REDIS_HOST");
    cfg.redis_port = get_env_int("REDIS_PORT", 6379);
    cfg.redis_password = get_env("REDIS_PASSWORD", "");
    cfg.redis_cmd_channel = get_env("REDIS_CMD_CHANNEL", "solscout:commands");
    cfg.redis_reply_channel = get_env("REDIS_REPLY_CHANNEL", "solscout:replies");
    cfg.redis_audit_channel = get_env("REDIS_AUDIT_CHANNEL", "solscout:audit");

    cfg.db_conn_string = get_env("DB_CONN_STRING");

    cfg.birdeye_api_key = get_env("BIRDEYE_API_KEY");
    cfg.solana_rpc_url = get_env("SOLANA_RPC_URL");
    
    cfg.health_check_port = get_env_int("HEALTH_CHECK_PORT", 8081);

    return cfg;
}

void Config::validate() const {
    if (redis_host.empty()) throw std::runtime_error("REDIS_HOST is not set");
    if (db_conn_string.empty()) throw std::runtime_error("DB_CONN_STRING is not set");
    if (birdeye_api_key.empty()) throw std::runtime_error("BIRDEYE_API_KEY is not set");
    if (solana_rpc_url.empty()) throw std::runtime_error("SOLANA_RPC_URL is not set");
}
