
#pragma once
#include <nlohmann/json.hpp>
#include <string>
#include <vector>
#include <map>

// Represents the user who initiated an action
struct Actor {
    int64_t tg_user_id;
    std::string role;

    NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Actor, tg_user_id, role);
};

// Represents a command request from tg_gateway
struct CommandRequest {
    std::string cmd;
    Actor from;
    std::string corr_id;
    std::string ts;
    nlohmann::json args;

    NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(CommandRequest, cmd, from, corr_id, ts, args);

    static CommandRequest from_json(const nlohmann::json& j) {
        return j.get<CommandRequest>();
    }
};

// Represents a reply to be sent back to tg_gateway
struct CommandReply {
    std::string corr_id;
    std::string message;
    std::string ts;

    NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(CommandReply, corr_id, message, ts);

    nlohmann::json to_json() const {
        return nlohmann::json(*this);
    }
};

// Represents an audit event to be published
struct Audit {
    std::string event;
    Actor actor;
    std::string detail;
    std::string ts;

    NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Audit, event, actor, detail, ts);
    
    nlohmann::json to_json() const {
        return nlohmann::json(*this);
    }
};
